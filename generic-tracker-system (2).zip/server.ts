import express from 'express';
import http from 'http';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { WebSocketServer, WebSocket } from 'ws';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const server = http.createServer(app);
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Ensure persistent data directory exists
const DATA_DIR = path.join(__dirname, 'data');
const DATA_FILE = path.join(DATA_DIR, 'tracker_store.json');
const SEED_FILE = path.join(DATA_DIR, 'default_seed.json');

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// In-Memory Authoritative Server State
interface ServerState {
  trackers: any[];
  folders: any[];
  users: any[];
  siteVisits: any[];
  decks: any[];
  changeRequests: any[];
  lastUpdated: string;
}

let serverState: ServerState = {
  trackers: [],
  folders: [],
  users: [],
  siteVisits: [],
  decks: [],
  changeRequests: [],
  lastUpdated: new Date().toISOString(),
};

// Load saved data from disk if available or pre-seed from seed file
function loadPersistedState(): void {
  try {
    if (fs.existsSync(DATA_FILE)) {
      const raw = fs.readFileSync(DATA_FILE, 'utf-8');
      const parsed = JSON.parse(raw);
      if (parsed && Array.isArray(parsed.trackers) && parsed.trackers.length > 0) {
        serverState = {
          trackers: parsed.trackers || [],
          folders: parsed.folders || [],
          users: parsed.users || [],
          siteVisits: parsed.siteVisits || [],
          decks: parsed.decks || [],
          changeRequests: parsed.changeRequests || [],
          lastUpdated: parsed.lastUpdated || new Date().toISOString(),
        };
        console.log(`[Real-Time Server] Loaded ${serverState.trackers.length} trackers from persistent disk.`);
        return;
      }
    }
  } catch (err) {
    console.warn('[Real-Time Server] Could not read disk store:', err);
  }

  // Pre-seed with default portfolio from seed file if present
  try {
    if (fs.existsSync(SEED_FILE)) {
      const raw = fs.readFileSync(SEED_FILE, 'utf-8');
      const parsed = JSON.parse(raw);
      if (parsed && Array.isArray(parsed.trackers) && parsed.trackers.length > 0) {
        serverState = {
          trackers: parsed.trackers || [],
          folders: parsed.folders || [],
          users: parsed.users || [],
          siteVisits: parsed.siteVisits || [],
          decks: parsed.decks || [],
          changeRequests: parsed.changeRequests || [],
          lastUpdated: new Date().toISOString(),
        };
        fs.writeFileSync(DATA_FILE, JSON.stringify(serverState, null, 2), 'utf-8');
        console.log('[Real-Time Server] Initialized and saved initial portfolio to disk from seed file.');
        return;
      }
    }
  } catch (err) {
    console.warn('[Real-Time Server] Could not read seed file:', err);
  }

  serverState = {
    trackers: [],
    folders: [],
    users: [],
    siteVisits: [],
    decks: [],
    changeRequests: [],
    lastUpdated: new Date().toISOString(),
  };
}

// Persist data to disk
let saveTimeout: NodeJS.Timeout | null = null;
function persistStateDebounced(): void {
  if (saveTimeout) clearTimeout(saveTimeout);
  saveTimeout = setTimeout(() => {
    try {
      serverState.lastUpdated = new Date().toISOString();
      fs.writeFileSync(DATA_FILE, JSON.stringify(serverState, null, 2), 'utf-8');
    } catch (err) {
      console.error('[Real-Time Server] Error saving state to disk:', err);
    }
  }, 300);
}

loadPersistedState();

// Active Presence Management
interface ConnectedClient {
  id: string;
  ws: WebSocket;
  user?: {
    id: string;
    name: string;
    email: string;
    role: string;
  };
  activeTrackerId?: string;
  connectedAt: string;
  lastPing: number;
}

const connectedClients = new Map<string, ConnectedClient>();

function getOnlineUsersList() {
  const usersMap = new Map<string, any>();
  for (const client of connectedClients.values()) {
    if (client.user) {
      usersMap.set(client.user.id || client.user.email, {
        ...client.user,
        activeTrackerId: client.activeTrackerId,
        connectedAt: client.connectedAt,
        clientId: client.id,
      });
    }
  }
  return Array.from(usersMap.values());
}

function broadcastToClients(message: any, excludeClientId?: string) {
  const json = JSON.stringify(message);
  for (const [clientId, client] of connectedClients.entries()) {
    if (excludeClientId && clientId === excludeClientId) continue;
    if (client.ws.readyState === WebSocket.OPEN) {
      client.ws.send(json);
    }
  }
}

// Setup WebSocket Server
const wss = new WebSocketServer({ noServer: true });

server.on('upgrade', (request, socket, head) => {
  const url = new URL(request.url || '', `http://${request.headers.host || 'localhost'}`);
  if (url.pathname === '/ws') {
    wss.handleUpgrade(request, socket, head, (ws) => {
      wss.emit('connection', ws, request);
    });
  }
});

wss.on('connection', (ws: WebSocket) => {
  const clientId = 'client_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7);

  const clientInfo: ConnectedClient = {
    id: clientId,
    ws,
    connectedAt: new Date().toISOString(),
    lastPing: Date.now(),
  };

  connectedClients.set(clientId, clientInfo);

  // Send initial handshake with current state and online users
  ws.send(
    JSON.stringify({
      type: 'INIT',
      payload: {
        clientId,
        state: serverState,
        onlineUsers: getOnlineUsersList(),
        serverTime: new Date().toISOString(),
      },
    })
  );

  ws.on('message', (data: Buffer | string) => {
    try {
      const msg = JSON.parse(data.toString());
      clientInfo.lastPing = Date.now();

      switch (msg.type) {
        case 'JOIN': {
          clientInfo.user = msg.payload?.user;
          clientInfo.activeTrackerId = msg.payload?.activeTrackerId;
          const onlineUsers = getOnlineUsersList();
          broadcastToClients({
            type: 'PRESENCE_UPDATE',
            payload: { onlineUsers },
          });
          break;
        }

        case 'PING': {
          ws.send(JSON.stringify({ type: 'PONG', timestamp: Date.now() }));
          break;
        }

        case 'UPDATE_STATE': {
          if (msg.payload?.state) {
            serverState = {
              ...serverState,
              ...msg.payload.state,
              lastUpdated: new Date().toISOString(),
            };
            persistStateDebounced();
            broadcastToClients(
              {
                type: 'STATE_UPDATED',
                payload: {
                  state: serverState,
                  senderId: clientId,
                  userName: clientInfo.user?.name || 'Teammate',
                },
              },
              clientId
            );
          }
          break;
        }

        case 'UPDATE_TRACKER': {
          const tracker = msg.payload?.tracker;
          if (tracker && tracker.id) {
            const idx = serverState.trackers.findIndex((t) => t.id === tracker.id);
            if (idx >= 0) {
              serverState.trackers[idx] = tracker;
            } else {
              serverState.trackers.push(tracker);
            }
            serverState.lastUpdated = new Date().toISOString();
            persistStateDebounced();

            broadcastToClients(
              {
                type: 'TRACKER_UPDATED',
                payload: {
                  tracker,
                  trackerId: tracker.id,
                  senderId: clientId,
                  userName: clientInfo.user?.name || 'Teammate',
                  timestamp: new Date().toISOString(),
                },
              },
              clientId
            );
          }
          break;
        }

        case 'UPDATE_ROW': {
          const { trackerId, row } = msg.payload || {};
          if (trackerId && row) {
            const tracker = serverState.trackers.find((t) => t.id === trackerId);
            if (tracker) {
              const rIdx = tracker.rows.findIndex((r: any) => r.id === row.id);
              if (rIdx >= 0) {
                tracker.rows[rIdx] = row;
              } else {
                tracker.rows.push(row);
              }
              tracker.updatedAt = new Date().toISOString();
              serverState.lastUpdated = new Date().toISOString();
              persistStateDebounced();

              broadcastToClients(
                {
                  type: 'ROW_UPDATED',
                  payload: {
                    trackerId,
                    row,
                    senderId: clientId,
                    userName: clientInfo.user?.name || 'Teammate',
                    timestamp: new Date().toISOString(),
                  },
                },
                clientId
              );
            }
          }
          break;
        }

        case 'DELETE_ROW': {
          const { trackerId, rowId } = msg.payload || {};
          if (trackerId && rowId) {
            const tracker = serverState.trackers.find((t) => t.id === trackerId);
            if (tracker) {
              tracker.rows = tracker.rows.filter((r: any) => r.id !== rowId);
              tracker.updatedAt = new Date().toISOString();
              serverState.lastUpdated = new Date().toISOString();
              persistStateDebounced();

              broadcastToClients(
                {
                  type: 'ROW_DELETED',
                  payload: {
                    trackerId,
                    rowId,
                    senderId: clientId,
                    userName: clientInfo.user?.name || 'Teammate',
                    timestamp: new Date().toISOString(),
                  },
                },
                clientId
              );
            }
          }
          break;
        }

        case 'UPDATE_FOLDERS': {
          if (Array.isArray(msg.payload?.folders)) {
            serverState.folders = msg.payload.folders;
            persistStateDebounced();
            broadcastToClients(
              {
                type: 'FOLDERS_UPDATED',
                payload: {
                  folders: serverState.folders,
                  senderId: clientId,
                  userName: clientInfo.user?.name || 'Teammate',
                },
              },
              clientId
            );
          }
          break;
        }

        case 'UPDATE_USERS': {
          if (Array.isArray(msg.payload?.users)) {
            serverState.users = msg.payload.users;
            persistStateDebounced();
            broadcastToClients(
              {
                type: 'USERS_UPDATED',
                payload: {
                  users: serverState.users,
                  senderId: clientId,
                  userName: clientInfo.user?.name || 'Teammate',
                },
              },
              clientId
            );
          }
          break;
        }

        case 'UPDATE_VISITS': {
          if (Array.isArray(msg.payload?.siteVisits)) {
            serverState.siteVisits = msg.payload.siteVisits;
            persistStateDebounced();
            broadcastToClients(
              {
                type: 'VISITS_UPDATED',
                payload: {
                  siteVisits: serverState.siteVisits,
                  senderId: clientId,
                  userName: clientInfo.user?.name || 'Teammate',
                },
              },
              clientId
            );
          }
          break;
        }

        case 'UPDATE_DECKS': {
          if (Array.isArray(msg.payload?.decks)) {
            serverState.decks = msg.payload.decks;
            persistStateDebounced();
            broadcastToClients(
              {
                type: 'DECKS_UPDATED',
                payload: {
                  decks: serverState.decks,
                  senderId: clientId,
                  userName: clientInfo.user?.name || 'Teammate',
                },
              },
              clientId
            );
          }
          break;
        }

        case 'UPDATE_REQUESTS': {
          if (Array.isArray(msg.payload?.changeRequests)) {
            serverState.changeRequests = msg.payload.changeRequests;
            persistStateDebounced();
            broadcastToClients(
              {
                type: 'REQUESTS_UPDATED',
                payload: {
                  changeRequests: serverState.changeRequests,
                  senderId: clientId,
                  userName: clientInfo.user?.name || 'Teammate',
                },
              },
              clientId
            );
          }
          break;
        }
      }
    } catch (err) {
      console.warn('[Real-Time Server] WebSocket message parse error:', err);
    }
  });

  ws.on('close', () => {
    connectedClients.delete(clientId);
    broadcastToClients({
      type: 'PRESENCE_UPDATE',
      payload: { onlineUsers: getOnlineUsersList() },
    });
  });

  ws.on('error', (err) => {
    console.warn('[Real-Time Server] WebSocket client error:', err);
    connectedClients.delete(clientId);
  });
});

// Clean up stale client connections every 30 seconds
setInterval(() => {
  const now = Date.now();
  for (const [clientId, client] of connectedClients.entries()) {
    if (now - client.lastPing > 90000) {
      try {
        client.ws.terminate();
      } catch (e) {}
      connectedClients.delete(clientId);
    }
  }
}, 30000);

// REST API Endpoints
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    uptimeSeconds: Math.floor(process.uptime()),
    connectedClients: connectedClients.size,
    onlineUsersCount: getOnlineUsersList().length,
    serverTime: new Date().toISOString(),
    environment: process.env.NODE_ENV || 'development',
    serverType: 'Free Cloud Run Container Server',
    realTimeProtocol: 'WebSocket (ws/wss) + REST JSON Store',
  });
});

app.get('/api/state', (req, res) => {
  res.json({
    ...serverState,
    onlineUsers: getOnlineUsersList(),
    serverTime: new Date().toISOString(),
  });
});

app.post('/api/state', (req, res) => {
  const { state } = req.body;
  if (state) {
    serverState = {
      ...serverState,
      ...state,
      lastUpdated: new Date().toISOString(),
    };
    persistStateDebounced();
    broadcastToClients({
      type: 'STATE_UPDATED',
      payload: { state: serverState, userName: 'Admin/API' },
    });
    res.json({ success: true, serverState });
  } else {
    res.status(400).json({ error: 'Missing state body' });
  }
});

app.post('/api/trackers', (req, res) => {
  const { tracker } = req.body;
  if (!tracker || !tracker.id) {
    return res.status(400).json({ error: 'Invalid tracker object' });
  }

  const idx = serverState.trackers.findIndex((t) => t.id === tracker.id);
  if (idx >= 0) {
    serverState.trackers[idx] = tracker;
  } else {
    serverState.trackers.push(tracker);
  }
  serverState.lastUpdated = new Date().toISOString();
  persistStateDebounced();

  broadcastToClients({
    type: 'TRACKER_UPDATED',
    payload: { tracker, trackerId: tracker.id, userName: 'Team Sync' },
  });

  res.json({ success: true, tracker });
});

app.get('/api/presence', (req, res) => {
  res.json({
    onlineUsers: getOnlineUsersList(),
    totalConnected: connectedClients.size,
  });
});

// Vite Integration (Dev Middleware or Production Static Serving)
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`[Real-Time Server] 🚀 Free collaborative tracker server running on http://0.0.0.0:${PORT}`);
    console.log(`[Real-Time Server] 📡 Real-time WebSocket listening on ws://0.0.0.0:${PORT}/ws`);
  });
}

startServer().catch((err) => {
  console.error('[Real-Time Server] Failed to initialize server:', err);
  process.exit(1);
});
