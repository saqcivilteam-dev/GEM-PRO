import { Tracker, TrackerFolder, UserAccount, SiteVisitRecord, ExecutiveDeck, ChangeRequest, TrackerRow } from '../types/tracker';

export type ConnectionStatus = 'connected' | 'connecting' | 'disconnected' | 'error';

export interface OnlineUser {
  id: string;
  name: string;
  email: string;
  role: string;
  activeTrackerId?: string;
  connectedAt: string;
  clientId: string;
}

export interface RealtimeMessage {
  type: string;
  payload?: any;
}

class RealtimeClient {
  private socket: WebSocket | null = null;
  private status: ConnectionStatus = 'disconnected';
  private reconnectAttempts = 0;
  private maxReconnectAttempts = 20;
  private reconnectTimer: any = null;
  private heartbeatTimer: any = null;
  private listeners: Map<string, Set<(data: any) => void>> = new Map();
  private currentUser: UserAccount | null = null;
  private currentActiveTrackerId: string = '';
  private clientId: string = '';
  private lastInitPayload: any = null;

  constructor() {
    this.init();
  }

  public getLastInitPayload(): any {
    return this.lastInitPayload;
  }

  public getStatus(): ConnectionStatus {
    return this.status;
  }

  public getClientId(): string {
    return this.clientId;
  }

  public init() {
    if (typeof window === 'undefined') return;
    this.connect();
  }

  public setUser(user: UserAccount, activeTrackerId?: string) {
    this.currentUser = user;
    if (activeTrackerId) this.currentActiveTrackerId = activeTrackerId;
    if (this.socket && this.socket.readyState === WebSocket.OPEN) {
      this.send({
        type: 'JOIN',
        payload: {
          user: {
            id: user.id,
            name: user.name,
            email: user.email,
            role: user.role,
          },
          activeTrackerId: this.currentActiveTrackerId,
        },
      });
    }
  }

  public setActiveTracker(trackerId: string) {
    this.currentActiveTrackerId = trackerId;
    if (this.currentUser) {
      this.setUser(this.currentUser, trackerId);
    }
  }

  private connect() {
    if (this.socket && (this.socket.readyState === WebSocket.OPEN || this.socket.readyState === WebSocket.CONNECTING)) {
      return;
    }

    this.setStatus('connecting');

    try {
      const isHttps = window.location.protocol === 'https:';
      const wsProtocol = isHttps ? 'wss:' : 'ws:';
      const wsHost = window.location.host;
      const wsUrl = `${wsProtocol}//${wsHost}/ws`;

      this.socket = new WebSocket(wsUrl);

      this.socket.onopen = () => {
        this.setStatus('connected');
        this.reconnectAttempts = 0;
        this.startHeartbeat();

        if (this.currentUser) {
          this.setUser(this.currentUser, this.currentActiveTrackerId);
        }
      };

      this.socket.onmessage = (event) => {
        try {
          const msg: RealtimeMessage = JSON.parse(event.data);
          this.handleIncomingMessage(msg);
        } catch (e) {
          console.warn('[RealtimeClient] Failed to parse message:', e);
        }
      };

      this.socket.onclose = () => {
        this.setStatus('disconnected');
        this.stopHeartbeat();
        this.scheduleReconnect();
      };

      this.socket.onerror = (err) => {
        console.warn('[RealtimeClient] WebSocket error:', err);
        this.setStatus('error');
      };
    } catch (err) {
      console.warn('[RealtimeClient] Connection error:', err);
      this.setStatus('disconnected');
      this.scheduleReconnect();
    }
  }

  private startHeartbeat() {
    this.stopHeartbeat();
    this.heartbeatTimer = setInterval(() => {
      if (this.socket && this.socket.readyState === WebSocket.OPEN) {
        this.send({ type: 'PING' });
      }
    }, 25000);
  }

  private stopHeartbeat() {
    if (this.heartbeatTimer) {
      clearInterval(this.heartbeatTimer);
      this.heartbeatTimer = null;
    }
  }

  private scheduleReconnect() {
    if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
    if (this.reconnectAttempts >= this.maxReconnectAttempts) {
      console.log('[RealtimeClient] Max reconnect attempts reached, will retry on user action');
      return;
    }

    const delay = Math.min(1000 * Math.pow(1.5, this.reconnectAttempts), 15000);
    this.reconnectAttempts++;
    this.reconnectTimer = setTimeout(() => {
      this.connect();
    }, delay);
  }

  public retryConnection() {
    this.reconnectAttempts = 0;
    this.connect();
  }

  private setStatus(s: ConnectionStatus) {
    if (this.status !== s) {
      this.status = s;
      this.emit('status', s);
    }
  }

  private handleIncomingMessage(msg: RealtimeMessage) {
    switch (msg.type) {
      case 'INIT': {
        this.clientId = msg.payload?.clientId || '';
        this.lastInitPayload = msg.payload;
        this.emit('init', msg.payload);
        break;
      }
      case 'PRESENCE_UPDATE': {
        this.emit('presence', msg.payload?.onlineUsers || []);
        break;
      }
      case 'TRACKER_UPDATED': {
        this.emit('tracker_updated', msg.payload);
        break;
      }
      case 'ROW_UPDATED': {
        this.emit('row_updated', msg.payload);
        break;
      }
      case 'ROW_DELETED': {
        this.emit('row_deleted', msg.payload);
        break;
      }
      case 'STATE_UPDATED': {
        this.emit('state_updated', msg.payload);
        break;
      }
      case 'FOLDERS_UPDATED': {
        this.emit('folders_updated', msg.payload?.folders);
        break;
      }
      case 'USERS_UPDATED': {
        this.emit('users_updated', msg.payload?.users);
        break;
      }
      case 'VISITS_UPDATED': {
        this.emit('visits_updated', msg.payload?.siteVisits);
        break;
      }
      case 'DECKS_UPDATED': {
        this.emit('decks_updated', msg.payload?.decks);
        break;
      }
      case 'REQUESTS_UPDATED': {
        this.emit('requests_updated', msg.payload?.changeRequests);
        break;
      }
    }
  }

  public send(msg: RealtimeMessage) {
    if (this.socket && this.socket.readyState === WebSocket.OPEN) {
      this.socket.send(JSON.stringify(msg));
    }
  }

  // Helper sync methods
  public updateTracker(tracker: Tracker) {
    this.send({
      type: 'UPDATE_TRACKER',
      payload: { tracker },
    });
  }

  public updateRow(trackerId: string, row: TrackerRow) {
    this.send({
      type: 'UPDATE_ROW',
      payload: { trackerId, row },
    });
  }

  public deleteRow(trackerId: string, rowId: string) {
    this.send({
      type: 'DELETE_ROW',
      payload: { trackerId, rowId },
    });
  }

  public updateFullState(state: {
    trackers?: Tracker[];
    folders?: TrackerFolder[];
    users?: UserAccount[];
    siteVisits?: SiteVisitRecord[];
    decks?: ExecutiveDeck[];
    changeRequests?: ChangeRequest[];
  }) {
    this.send({
      type: 'UPDATE_STATE',
      payload: { state },
    });
  }

  public updateFolders(folders: TrackerFolder[]) {
    this.send({
      type: 'UPDATE_FOLDERS',
      payload: { folders },
    });
  }

  public updateUsers(users: UserAccount[]) {
    this.send({
      type: 'UPDATE_USERS',
      payload: { users },
    });
  }

  public updateVisits(siteVisits: SiteVisitRecord[]) {
    this.send({
      type: 'UPDATE_VISITS',
      payload: { siteVisits },
    });
  }

  public updateDecks(decks: ExecutiveDeck[]) {
    this.send({
      type: 'UPDATE_DECKS',
      payload: { decks },
    });
  }

  public updateChangeRequests(changeRequests: ChangeRequest[]) {
    this.send({
      type: 'UPDATE_REQUESTS',
      payload: { changeRequests },
    });
  }

  // Event listener subscription with replay
  public on(event: string, callback: (data: any) => void) {
    if (!this.listeners.has(event)) {
      this.listeners.set(event, new Set());
    }
    this.listeners.get(event)!.add(callback);

    // If subscribed to status, immediately notify with current status
    if (event === 'status') {
      try {
        callback(this.status);
      } catch (err) {}
    }

    // If subscribed to init and we already received the server init payload, immediately replay!
    if (event === 'init' && this.lastInitPayload) {
      try {
        callback(this.lastInitPayload);
      } catch (err) {
        console.error('[RealtimeClient] Error in replayed init listener:', err);
      }
    }

    return () => this.off(event, callback);
  }

  public off(event: string, callback: (data: any) => void) {
    const set = this.listeners.get(event);
    if (set) {
      set.delete(callback);
    }
  }

  private emit(event: string, data: any) {
    const set = this.listeners.get(event);
    if (set) {
      for (const cb of set) {
        try {
          cb(data);
        } catch (err) {
          console.error(`[RealtimeClient] Error in listener for ${event}:`, err);
        }
      }
    }
  }

  // REST API fallbacks
  public async fetchServerState() {
    try {
      const res = await fetch('/api/state');
      if (res.ok) {
        return await res.json();
      }
    } catch (e) {
      console.warn('[RealtimeClient] Failed to fetch REST state:', e);
    }
    return null;
  }

  public async fetchServerHealth() {
    try {
      const res = await fetch('/api/health');
      if (res.ok) {
        return await res.json();
      }
    } catch (e) {}
    return null;
  }
}

export const realtimeClient = new RealtimeClient();
