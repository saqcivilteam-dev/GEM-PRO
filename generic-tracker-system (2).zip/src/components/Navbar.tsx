import React, { useState, useRef, useEffect } from 'react';
import { UserAccount } from '../types/tracker';
import {
  Table,
  LayoutDashboard,
  BarChart3,
  ShieldAlert,
  MapPin,
  HardDrive,
  Presentation,
  Sun,
  Moon,
  Search,
  Lock,
  ShieldCheck,
  LogOut,
  UserPlus,
  Server,
  Save,
  Database,
  Check,
  RefreshCw,
  Cloud,
  ChevronDown,
  Users,
  Share2,
} from 'lucide-react';

export type ActiveView = 'tracker' | 'dashboard' | 'all_metrics' | 'warning_center' | 'attendance' | 'deck';

interface NavbarProps {
  activeView: ActiveView;
  onChangeView: (view: ActiveView) => void;
  currentUser: UserAccount;
  onOpenAuthModal: () => void;
  onOpenBackupModal: () => void;
  onOpenServerModal: () => void;
  onOpenSupabaseModal?: () => void;
  isSupabaseConnected?: boolean;
  onOpenCloudflareModal?: () => void;
  isCloudflareConnected?: boolean;
  onSaveChanges?: () => void;
  hasUnsavedChanges?: boolean;
  unsavedCount?: number;
  isSaving?: boolean;
  lastSavedTime?: string | null;
  onOpenGlobalSearch: () => void;
  onOpenLockModal?: () => void;
  isTrackerLocked?: boolean;
  pendingApprovalsCount?: number;
  pendingRegistrationsCount?: number;
  onLogout?: () => void;
  isDarkMode: boolean;
  onToggleTheme: () => void;
  criticalWarningCount: number;
  connectionStatus?: 'connected' | 'connecting' | 'disconnected' | 'error';
  onlineUsersCount?: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeView,
  onChangeView,
  currentUser,
  onOpenAuthModal,
  onOpenBackupModal,
  onOpenServerModal,
  onOpenSupabaseModal,
  isSupabaseConnected = false,
  onOpenCloudflareModal,
  isCloudflareConnected = false,
  onSaveChanges,
  hasUnsavedChanges = false,
  unsavedCount = 0,
  isSaving = false,
  lastSavedTime = null,
  onOpenGlobalSearch,
  onOpenLockModal,
  isTrackerLocked = false,
  pendingApprovalsCount = 0,
  pendingRegistrationsCount = 0,
  onLogout,
  isDarkMode,
  onToggleTheme,
  criticalWarningCount,
  connectionStatus = 'connected',
  onlineUsersCount = 1,
}) => {
  const [isCloudMenuOpen, setIsCloudMenuOpen] = useState(false);
  const [isViewMenuOpen, setIsViewMenuOpen] = useState(false);
  const cloudMenuRef = useRef<HTMLDivElement>(null);
  const viewMenuRef = useRef<HTMLDivElement>(null);

  // Close menus when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (cloudMenuRef.current && !cloudMenuRef.current.contains(event.target as Node)) {
        setIsCloudMenuOpen(false);
      }
      if (viewMenuRef.current && !viewMenuRef.current.contains(event.target as Node)) {
        setIsViewMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const navItems: { view: ActiveView; label: string; shortLabel: string; icon: React.ElementType; badge?: number }[] = [
    { view: 'tracker', label: 'Excel Tracker', shortLabel: 'Tracker', icon: Table },
    { view: 'dashboard', label: 'Dashboard', shortLabel: 'Dashboard', icon: LayoutDashboard },
    { view: 'all_metrics', label: 'All Metrics Hub', shortLabel: 'Metrics', icon: BarChart3 },
    { view: 'warning_center', label: 'SLA Warning Center', shortLabel: 'SLA Alert', icon: ShieldAlert, badge: criticalWarningCount },
    { view: 'attendance', label: 'Staff Site GPS', shortLabel: 'Site GPS', icon: MapPin },
    { view: 'deck', label: 'Presentation Deck', shortLabel: 'Deck', icon: Presentation },
  ];

  const currentNav = navItems.find((item) => item.view === activeView) || navItems[0];
  const CurrentNavIcon = currentNav.icon;

  return (
    <header className="no-print h-14 w-full bg-slate-950 border-b border-slate-800 px-3 md:px-5 flex items-center justify-between gap-2 shrink-0 z-40 relative">
      {/* Zone 1: Wordmark Logo */}
      <div className="flex items-center gap-2.5 shrink-0">
        <a
          href="#"
          onClick={(e) => {
            e.preventDefault();
            onChangeView('tracker');
          }}
          className="text-sm sm:text-base font-extrabold tracking-tight text-white hover:text-sky-300 transition-colors whitespace-nowrap flex items-center gap-1.5"
        >
          <span className="px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 text-[10px] font-black tracking-wider uppercase">
            GEM PRO
          </span>
          <span className="hidden sm:inline font-bold text-slate-100">Generic Tracker</span>
        </a>
      </div>

      {/* Zone 2: Navigation Controls */}
      {/* 2A: Desktop Nav (visible on xl and wider) */}
      <nav className="hidden xl:flex items-center gap-0.5 bg-slate-900/90 p-1 rounded-lg border border-slate-800 shrink-0">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeView === item.view;
          return (
            <button
              key={item.view}
              type="button"
              onClick={() => onChangeView(item.view)}
              className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-colors whitespace-nowrap flex items-center gap-1.5 ${
                isActive
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
              }`}
              title={item.label}
            >
              <Icon className="w-3.5 h-3.5 shrink-0" />
              <span>{item.shortLabel}</span>
              {item.badge !== undefined && item.badge > 0 && (
                <span className="px-1.5 py-0.2 rounded-full bg-rose-600 text-white text-[10px] font-bold">
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* 2B: Compact View Selector (for screens below xl) */}
      <div className="flex xl:hidden items-center relative" ref={viewMenuRef}>
        <button
          type="button"
          onClick={() => setIsViewMenuOpen(!isViewMenuOpen)}
          className="px-2.5 py-1.5 text-xs font-semibold rounded-lg bg-slate-900 border border-slate-800 text-slate-200 flex items-center gap-1.5 hover:bg-slate-850 hover:border-slate-700 transition-colors"
        >
          <CurrentNavIcon className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
          <span className="font-semibold">{currentNav.shortLabel}</span>
          {currentNav.badge !== undefined && currentNav.badge > 0 && (
            <span className="px-1.5 py-0.2 rounded-full bg-rose-600 text-white text-[10px] font-bold">
              {currentNav.badge}
            </span>
          )}
          <ChevronDown className={`w-3 h-3 text-slate-400 transition-transform ${isViewMenuOpen ? 'rotate-180' : ''}`} />
        </button>

        {isViewMenuOpen && (
          <div className="absolute top-full left-0 mt-1.5 w-48 bg-slate-900 border border-slate-800 rounded-xl shadow-2xl py-1 z-50 animate-in fade-in slide-in-from-top-2 duration-150">
            <div className="px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-400 border-b border-slate-800">
              Select Workspace View
            </div>
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeView === item.view;
              return (
                <button
                  key={item.view}
                  type="button"
                  onClick={() => {
                    onChangeView(item.view);
                    setIsViewMenuOpen(false);
                  }}
                  className={`w-full px-3 py-2 text-left text-xs font-medium flex items-center justify-between gap-2 hover:bg-slate-800 transition-colors ${
                    isActive ? 'text-indigo-400 bg-slate-800/60 font-bold' : 'text-slate-300'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <Icon className="w-3.5 h-3.5 shrink-0" />
                    <span>{item.label}</span>
                  </div>
                  {item.badge !== undefined && item.badge > 0 && (
                    <span className="px-1.5 py-0.2 rounded-full bg-rose-600 text-white text-[10px] font-bold">
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        )}
      </div>

      {/* Zone 3: Actions + Cloud & Sync Hub + User Profile */}
      <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
        {/* 1. Global Save Changes Button (Compact & Highly Visible) */}
        {onSaveChanges && (
          <button
            type="button"
            onClick={onSaveChanges}
            disabled={isSaving}
            className={`px-2.5 sm:px-3 py-1.5 text-xs font-bold rounded-lg border flex items-center gap-1.5 transition-all cursor-pointer shadow-xs ${
              hasUnsavedChanges
                ? 'bg-emerald-600 hover:bg-emerald-500 text-white border-emerald-500 ring-2 ring-emerald-400/40 animate-pulse'
                : 'bg-slate-900 hover:bg-slate-850 text-slate-200 border-slate-800'
            }`}
            title={`Save changes to Local Storage, Real-Time Server, and Supabase (Ctrl+S / Cmd+S)${
              lastSavedTime ? ` · Last saved at ${lastSavedTime}` : ''
            }`}
          >
            {isSaving ? (
              <RefreshCw className="w-3.5 h-3.5 animate-spin text-emerald-300 shrink-0" />
            ) : hasUnsavedChanges ? (
              <Save className="w-3.5 h-3.5 text-white shrink-0" />
            ) : (
              <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
            )}
            <span>{isSaving ? 'Saving...' : hasUnsavedChanges ? 'Save' : 'Saved'}</span>
            {hasUnsavedChanges && unsavedCount > 0 && (
              <span className="px-1.5 py-0.2 rounded-full bg-black/40 text-white text-[10px] font-mono font-bold">
                {unsavedCount}
              </span>
            )}
          </button>
        )}

        {/* Instant Free Team Share Button (Zero Trouble) */}
        <button
          type="button"
          onClick={onOpenServerModal}
          className="px-2.5 py-1.5 text-xs font-bold rounded-lg border flex items-center gap-1.5 transition-all cursor-pointer shadow-sm bg-emerald-950/70 hover:bg-emerald-900/90 border-emerald-600/70 text-emerald-200 hover:text-white"
          title="Share live tracker with your team - 100% Free real-time sync with 0 setup"
        >
          <Users className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
          <span className="hidden sm:inline">Share with Team</span>
          <span className="sm:hidden">Share</span>
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse shrink-0" title="Live Database Active" />
        </button>

        {/* 2. Organized Cloud & Sync Hub Menu */}
        <div className="relative" ref={cloudMenuRef}>
          <button
            type="button"
            onClick={() => setIsCloudMenuOpen(!isCloudMenuOpen)}
            className={`px-2.5 py-1.5 text-xs font-semibold rounded-lg border flex items-center gap-1.5 transition-colors cursor-pointer shadow-xs ${
              isCloudMenuOpen
                ? 'bg-slate-800 border-indigo-500 text-white'
                : isSupabaseConnected || connectionStatus === 'connected'
                ? 'bg-slate-900 border-slate-700 text-slate-200 hover:bg-slate-800'
                : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
            title="Cloud & Sync Hub: Free Team Database, Supabase, Cloudflare & Lock settings"
          >
            <Cloud className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
            <span className="hidden sm:inline">Sync Hub</span>
            {/* Live indicators */}
            <div className="flex items-center gap-1">
              {connectionStatus === 'connected' && (
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" title="Live Real-time Database Connected" />
              )}
              {isCloudflareConnected && (
                <span className="w-1.5 h-1.5 rounded-full bg-orange-400" title="Cloudflare Connected" />
              )}
              {isSupabaseConnected && (
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" title="Supabase Connected" />
              )}
              {connectionStatus === 'connected' && (
                <span className="px-1 py-0.1 rounded text-[9px] font-mono font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  {onlineUsersCount}
                </span>
              )}
            </div>
            <ChevronDown className={`w-3 h-3 text-slate-400 transition-transform ${isCloudMenuOpen ? 'rotate-180' : ''}`} />
          </button>

          {/* Cloud & Sync Dropdown Panel */}
          {isCloudMenuOpen && (
            <div className="absolute right-0 top-full mt-1.5 w-72 sm:w-80 bg-slate-900 border border-slate-800 rounded-xl shadow-2xl p-2 z-50 animate-in fade-in slide-in-from-top-2 duration-150">
              <div className="px-2.5 py-1.5 text-[11px] font-bold uppercase tracking-wider text-slate-400 flex items-center justify-between border-b border-slate-800/80 mb-1.5">
                <span>Cloud &amp; Sync Integrations</span>
                <span className="text-[10px] font-normal text-emerald-400 font-semibold">100% Free Live</span>
              </div>

              {/* 1. Collaborative Team Server Card (BUILT-IN & FREE - RECOMMENDED) */}
              <button
                type="button"
                onClick={() => {
                  setIsCloudMenuOpen(false);
                  onOpenServerModal();
                }}
                className="w-full p-2.5 rounded-lg bg-emerald-950/40 hover:bg-emerald-900/60 border border-emerald-700/60 transition-colors flex items-start gap-2.5 text-left mb-1.5"
              >
                <div className="p-1.5 rounded-md shrink-0 bg-emerald-500/20 text-emerald-400">
                  <Server className="w-4 h-4" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-1">
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs font-bold text-white">Live Team Database</span>
                      <span className="text-[9px] font-bold px-1.5 py-0.2 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                        Built-in Free
                      </span>
                    </div>
                    <span className="text-[10px] font-bold px-1.5 py-0.2 rounded-full bg-emerald-500/20 text-emerald-300">
                      Active
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-300 truncate mt-0.5">
                    Zero setup · WebSockets &amp; instant team sharing
                  </p>
                </div>
              </button>

              {/* 2. Cloudflare Real-Time DB Card (Optional) */}
              {onOpenCloudflareModal && (
                <button
                  type="button"
                  onClick={() => {
                    setIsCloudMenuOpen(false);
                    onOpenCloudflareModal();
                  }}
                  className="w-full p-2 rounded-lg hover:bg-slate-800/80 transition-colors flex items-start gap-2.5 text-left border border-transparent hover:border-slate-700/60 mb-1"
                >
                  <div className={`p-1.5 rounded-md shrink-0 ${isCloudflareConnected ? 'bg-orange-500/15 text-orange-400' : 'bg-slate-800 text-slate-400'}`}>
                    <Cloud className="w-4 h-4" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-1">
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs font-bold text-white">Cloudflare Edge DB</span>
                        <span className="text-[9px] font-bold px-1.5 py-0.2 rounded-full bg-orange-500/20 text-orange-300 border border-orange-500/30">
                          Optional
                        </span>
                      </div>
                      <span className={`text-[10px] font-semibold px-1.5 py-0.2 rounded-full ${
                        isCloudflareConnected ? 'bg-emerald-500/20 text-emerald-300' : 'bg-slate-800 text-slate-400'
                      }`}>
                        {isCloudflareConnected ? 'Connected' : 'Setup'}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400 truncate mt-0.5">
                      Edge worker backup &amp; external sync
                    </p>
                  </div>
                </button>
              )}

              {/* 3. Supabase Database Card */}
              {onOpenSupabaseModal && (
                <button
                  type="button"
                  onClick={() => {
                    setIsCloudMenuOpen(false);
                    onOpenSupabaseModal();
                  }}
                  className="w-full p-2 rounded-lg hover:bg-slate-800/80 transition-colors flex items-start gap-2.5 text-left border border-transparent hover:border-slate-700/60 mb-1"
                >
                  <div className={`p-1.5 rounded-md shrink-0 ${isSupabaseConnected ? 'bg-emerald-500/15 text-emerald-400' : 'bg-slate-800 text-slate-400'}`}>
                    <Database className="w-4 h-4" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-1">
                      <span className="text-xs font-bold text-white">Supabase PostgreSQL</span>
                      <span className={`text-[10px] font-semibold px-1.5 py-0.2 rounded-full ${
                        isSupabaseConnected ? 'bg-emerald-500/20 text-emerald-300' : 'bg-slate-800 text-slate-400'
                      }`}>
                        {isSupabaseConnected ? 'Connected' : 'Configure'}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400 truncate mt-0.5">
                      Cloud persistence &amp; automatic database sync
                    </p>
                  </div>
                </button>
              )}

              {/* C. Google Drive Backup Card */}
              <button
                type="button"
                onClick={() => {
                  setIsCloudMenuOpen(false);
                  onOpenBackupModal();
                }}
                className="w-full p-2 rounded-lg hover:bg-slate-800/80 transition-colors flex items-start gap-2.5 text-left border border-transparent hover:border-slate-700/60 mb-1"
              >
                <div className="p-1.5 rounded-md bg-sky-500/15 text-sky-400 shrink-0">
                  <HardDrive className="w-4 h-4" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-1">
                    <span className="text-xs font-bold text-white">Google Drive Backup</span>
                    <span className="text-[10px] font-semibold px-1.5 py-0.2 rounded-full bg-slate-800 text-sky-300">
                      Cloud Archive
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 truncate mt-0.5">
                    Save snapshots & restore backups to Google Drive
                  </p>
                </div>
              </button>

              {/* D. Data Lock & Approvals Card */}
              {onOpenLockModal && (
                <button
                  type="button"
                  onClick={() => {
                    setIsCloudMenuOpen(false);
                    onOpenLockModal();
                  }}
                  className="w-full p-2 rounded-lg hover:bg-slate-800/80 transition-colors flex items-start gap-2.5 text-left border border-transparent hover:border-slate-700/60"
                >
                  <div className={`p-1.5 rounded-md shrink-0 ${isTrackerLocked ? 'bg-amber-500/15 text-amber-400' : 'bg-emerald-500/15 text-emerald-400'}`}>
                    {isTrackerLocked ? <Lock className="w-4 h-4" /> : <ShieldCheck className="w-4 h-4" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-1">
                      <span className="text-xs font-bold text-white">
                        {isTrackerLocked ? 'Protected (Locked)' : 'Direct Edit Active'}
                      </span>
                      {pendingApprovalsCount > 0 ? (
                        <span className="text-[10px] font-bold px-1.5 py-0.2 rounded-full bg-amber-500 text-black">
                          {pendingApprovalsCount} Pending
                        </span>
                      ) : (
                        <span className="text-[10px] font-semibold px-1.5 py-0.2 rounded-full bg-slate-800 text-slate-400">
                          Settings
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-slate-400 truncate mt-0.5">
                      Cell editing permissions & admin approvals
                    </p>
                  </div>
                </button>
              )}
            </div>
          )}
        </div>

        {/* 3. Global Search */}
        <button
          type="button"
          onClick={onOpenGlobalSearch}
          className="p-1.5 sm:p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          title="Search in current or all trackers (Ctrl+F)"
        >
          <Search className="w-4 h-4" />
        </button>

        {/* 4. Appearance Theme Switcher */}
        <button
          type="button"
          onClick={onToggleTheme}
          className="p-1.5 sm:p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          title={isDarkMode ? 'Switch to Light Theme' : 'Switch to Midnight Theme'}
        >
          {isDarkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-indigo-400" />}
        </button>

        {/* 5. Admin Approvals Alert (if any pending registrations) */}
        {(currentUser.role === 'admin' || currentUser.role === 'creator') && pendingRegistrationsCount > 0 && (
          <button
            type="button"
            onClick={onOpenAuthModal}
            className="px-2 py-1 rounded-lg bg-amber-950/80 border border-amber-800 text-amber-300 text-xs font-semibold flex items-center gap-1 hover:bg-amber-900 transition-colors animate-pulse"
            title={`${pendingRegistrationsCount} accounts awaiting Admin approval`}
          >
            <UserPlus className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <span className="hidden md:inline">Approvals</span>
            <span className="px-1.5 py-0.2 rounded-full bg-amber-500 text-black text-[10px] font-black">
              {pendingRegistrationsCount}
            </span>
          </button>
        )}

        {/* 6. User Account Card */}
        <button
          type="button"
          onClick={onOpenAuthModal}
          className="flex items-center gap-1.5 pl-1.5 pr-2 py-1 rounded-lg bg-slate-900 hover:bg-slate-850 border border-slate-800 text-xs transition-colors shrink-0"
          title="Manage Account, Switch Persona, or View Approvals"
        >
          <div className="w-6 h-6 rounded-full bg-indigo-600 flex items-center justify-center font-bold text-[11px] text-white shrink-0">
            {currentUser.name.charAt(0)}
          </div>
          <div className="text-left hidden lg:block max-w-[85px] truncate leading-tight">
            <div className="font-semibold text-white leading-none truncate text-[11px]">
              {currentUser.name}
            </div>
            <div className="text-[9px] text-sky-400 font-mono uppercase mt-0.5 leading-none">
              {currentUser.role}
            </div>
          </div>
        </button>

        {/* 7. Sign Out */}
        {onLogout && (
          <button
            type="button"
            onClick={onLogout}
            className="p-1.5 sm:p-2 text-slate-400 hover:text-rose-400 rounded-lg hover:bg-slate-800 transition-colors shrink-0"
            title="Sign Out / Return to Landing Page"
          >
            <LogOut className="w-4 h-4" />
          </button>
        )}
      </div>
    </header>
  );
};
