import React, { useState } from 'react';
import { Tracker, TrackerFolder, UserAccount, SiteVisitRecord } from '../types/tracker';
import {
  Cloud,
  HardDrive,
  Download,
  Upload,
  RefreshCw,
  CheckCircle2,
  Share2,
  X,
  FileSpreadsheet,
  Copy,
  Clock,
  ShieldCheck,
} from 'lucide-react';
import { getPublicShareUrl } from '../utils/shareUtils';

interface GoogleDriveBackupModalProps {
  isOpen: boolean;
  onClose: () => void;
  trackers: Tracker[];
  folders: TrackerFolder[];
  users: UserAccount[];
  visits: SiteVisitRecord[];
  onRestoreFullState: (restored: {
    trackers: Tracker[];
    folders: TrackerFolder[];
    users: UserAccount[];
    visits: SiteVisitRecord[];
  }) => void;
}

export const GoogleDriveBackupModal: React.FC<GoogleDriveBackupModalProps> = ({
  isOpen,
  onClose,
  trackers,
  folders,
  users,
  visits,
  onRestoreFullState,
}) => {
  if (!isOpen) return null;

  const [cloudSyncEnabled, setCloudSyncEnabled] = useState(true);
  const [shareRoomId, setShareRoomId] = useState('GT-ROOM-SAQCIVIL-2026');
  const [lastBackupTime, setLastBackupTime] = useState<string | null>(() => localStorage.getItem('gt_last_backup_time'));
  const [restoreStatus, setRestoreStatus] = useState<string | null>(null);

  const handleDownloadBackupArchive = () => {
    const backupPayload = {
      version: '1.2.0',
      exportedAt: new Date().toISOString(),
      generator: 'GEM PRO Generic Tracker System',
      targetStorage: 'Personal Google Drive / Cloud Cold Storage',
      data: {
        trackers,
        folders,
        users,
        visits,
      },
    };

    const blob = new Blob([JSON.stringify(backupPayload, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    a.href = url;
    a.download = `GEM_PRO_Generic_Tracker_GoogleDrive_Backup_${timestamp}.json`;
    a.click();
    URL.revokeObjectURL(url);

    const now = new Date().toLocaleString('en-PH');
    setLastBackupTime(now);
    localStorage.setItem('gt_last_backup_time', now);
  };

  const handleRestoreFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        if (parsed.data && parsed.data.trackers) {
          onRestoreFullState(parsed.data);
          setRestoreStatus(`Successfully restored ${parsed.data.trackers.length} trackers and ${parsed.data.visits?.length || 0} visits!`);
        } else {
          setRestoreStatus('Invalid backup format: missing tracker data.');
        }
      } catch (err) {
        setRestoreStatus('Failed to parse backup JSON file.');
      }
    };
    reader.readAsText(file);
  };

  const handleCopyShareLink = () => {
    const shareUrl = getPublicShareUrl();
    navigator.clipboard.writeText(shareUrl);
    alert('Real-time collaboration link copied! Share this link with team members.');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="relative w-full max-w-2xl max-h-[92vh] flex flex-col rounded-xl bg-slate-900 border border-slate-700 text-slate-100 shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800 bg-slate-950 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-sky-500/20 text-sky-400 rounded-lg">
              <Cloud className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white tracking-wide">
                Google Drive Backup & Free Cloud Sharing
              </h2>
              <p className="text-xs text-slate-400">
                Encrypted database exports, personal Drive sync, and real-time team sharing
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Section 1: Google Drive Backup */}
          <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
                <HardDrive className="w-4 h-4 text-emerald-400" />
                Google Drive Backup Archive
              </h3>
              {lastBackupTime && (
                <span className="text-[11px] text-slate-400 flex items-center gap-1 font-mono">
                  <Clock className="w-3 h-3 text-emerald-400" />
                  Last Backup: {lastBackupTime}
                </span>
              )}
            </div>

            <p className="text-xs text-slate-400 leading-relaxed">
              Export an all-in-one consolidated backup archive containing all trackers, columns, SLA milestone logs, statutory legal checklists, and staff attendance geotags to save in your personal Google Drive account.
            </p>

            <div className="pt-2 flex flex-wrap items-center gap-3">
              <button
                type="button"
                onClick={handleDownloadBackupArchive}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-bold flex items-center gap-2 shadow-xs transition-colors"
              >
                <Download className="w-4 h-4" />
                Download Google Drive Backup (.json)
              </button>

              <label className="px-4 py-2 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 rounded-lg text-xs font-semibold flex items-center gap-2 cursor-pointer transition-colors">
                <Upload className="w-4 h-4 text-sky-400" />
                Restore From Backup File
                <input
                  type="file"
                  accept=".json"
                  className="hidden"
                  onChange={handleRestoreFile}
                />
              </label>
            </div>

            {restoreStatus && (
              <div className="p-2.5 rounded bg-emerald-950/50 border border-emerald-800/80 text-emerald-300 text-xs flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4" />
                {restoreStatus}
              </div>
            )}
          </div>

          {/* Section 2: Real-time Cloud Sharing */}
          <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
                <Share2 className="w-4 h-4 text-sky-400" />
                Free Centralized Cloud Room & Real-time Collaboration
              </h3>
              <div className="flex items-center gap-2">
                <span className="text-[11px] text-slate-400">Cloud Sync:</span>
                <button
                  type="button"
                  onClick={() => setCloudSyncEnabled(!cloudSyncEnabled)}
                  className={`w-9 h-5 rounded-full p-0.5 transition-colors ${
                    cloudSyncEnabled ? 'bg-emerald-600' : 'bg-slate-700'
                  }`}
                >
                  <div
                    className={`w-4 h-4 rounded-full bg-white transition-transform ${
                      cloudSyncEnabled ? 'translate-x-4' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed">
              Enables team members with authorized links to collaborate across the same trackers without paid third-party database licenses.
            </p>

            <div className="flex items-center gap-2">
              <input
                type="text"
                readOnly
                value={getPublicShareUrl()}
                className="flex-1 px-3 py-2 bg-slate-900 border border-slate-700 rounded-md text-xs font-mono text-slate-300 truncate"
              />
              <button
                type="button"
                onClick={handleCopyShareLink}
                className="px-3.5 py-2 bg-sky-600 hover:bg-sky-500 text-white rounded-md text-xs font-bold flex items-center gap-1.5 transition-colors shrink-0"
              >
                <Copy className="w-3.5 h-3.5" />
                Copy Share Link
              </button>
            </div>
          </div>

          {/* Section 3: Storage Health */}
          <div className="p-3.5 rounded-lg bg-indigo-950/30 border border-indigo-900/60 text-xs text-indigo-300 flex items-start gap-2.5">
            <ShieldCheck className="w-4 h-4 shrink-0 mt-0.5" />
            <div>
              <strong>Automatic Local Persistence:</strong> Every cell edit, row creation, and SLA milestone timestamp is automatically cached in browser storage. Download periodic backups to keep historical revisions in Google Drive.
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-800 bg-slate-950 flex items-center justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded font-semibold text-xs transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
