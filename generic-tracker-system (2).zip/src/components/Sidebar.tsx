import React, { useState } from 'react';
import { Tracker, TrackerFolder, UserRole } from '../types/tracker';
import {
  FolderPlus,
  Plus,
  Copy,
  Edit2,
  Trash2,
  Folder,
  FolderOpen,
  ChevronLeft,
  ChevronRight,
  ChevronDown,
  Table,
  Check,
  X,
  Search,
  AlertTriangle,
  Info,
} from 'lucide-react';

interface SidebarProps {
  trackers: Tracker[];
  folders: TrackerFolder[];
  activeTrackerId: string;
  isCollapsed: boolean;
  onToggleCollapse: () => void;
  onSelectTracker: (trackerId: string) => void;
  onCreateTracker: (folderId?: string) => void;
  onDuplicateTracker: (trackerId: string) => void;
  onRenameTracker: (trackerId: string, newName: string) => void;
  onDeleteTracker: (trackerId: string) => void;
  onCreateFolder: (folderName: string) => void;
  onRenameFolder: (folderId: string, newName: string) => void;
  onDeleteFolder?: (folderId: string) => void;
  onOpenGlobalSearch: () => void;
  canEdit: boolean;
  isAdmin?: boolean;
  currentUserRole?: UserRole;
  assignedProjects?: string[];
}

export const Sidebar: React.FC<SidebarProps> = ({
  trackers,
  folders,
  activeTrackerId,
  isCollapsed,
  onToggleCollapse,
  onSelectTracker,
  onCreateTracker,
  onDuplicateTracker,
  onRenameTracker,
  onDeleteTracker,
  onCreateFolder,
  onRenameFolder,
  onDeleteFolder,
  onOpenGlobalSearch,
  canEdit,
  isAdmin,
  currentUserRole = 'admin',
  assignedProjects = [],
}) => {
  // Tracker renaming state
  const [editingTrackerId, setEditingTrackerId] = useState<string | null>(null);
  const [editingTrackerName, setEditingTrackerName] = useState('');

  // Folder renaming state
  const [editingFolderId, setEditingFolderId] = useState<string | null>(null);
  const [editingFolderName, setEditingFolderName] = useState('');

  // New folder input state
  const [newFolderName, setNewFolderName] = useState('');
  const [showNewFolderInput, setShowNewFolderInput] = useState(false);

  // In-App Deletion Modals (replaces window.confirm which is blocked in iframes)
  const [trackerToDelete, setTrackerToDelete] = useState<Tracker | null>(null);
  const [folderToDelete, setFolderToDelete] = useState<TrackerFolder | null>(null);
  const [cannotDeleteNotice, setCannotDeleteNotice] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Permissions calculation
  const isUserAdmin = isAdmin ?? (currentUserRole === 'admin' || currentUserRole === 'creator');
  const isUserGuest = currentUserRole === 'guest';

  // Can manage this specific tracker
  const canManageTracker = (t: Tracker) => {
    if (isUserAdmin) return true;
    if (isUserGuest) return false;
    if (currentUserRole === 'staff') {
      return assignedProjects ? assignedProjects.includes(t.id) : canEdit;
    }
    return canEdit;
  };

  const canCreate = isUserAdmin || (currentUserRole === 'staff' && canEdit);

  // Folder collapse states
  const [expandedFolders, setExpandedFolders] = useState<Record<string, boolean>>({
    folder_civil: true,
    folder_legal: true,
    folder_sla: true,
  });

  // Start folder rename
  const handleStartRenameFolder = (folder: TrackerFolder, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setEditingFolderId(folder.id);
    setEditingFolderName(folder.name);
  };

  // Confirm folder rename
  const handleConfirmRenameFolder = (folderId: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    if (editingFolderName.trim()) {
      onRenameFolder(folderId, editingFolderName.trim());
    }
    setEditingFolderId(null);
  };

  // Cancel folder rename
  const handleCancelRenameFolder = (e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setEditingFolderId(null);
  };

  // Start tracker rename
  const handleStartRenameTracker = (tracker: Tracker, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setEditingTrackerId(tracker.id);
    setEditingTrackerName(tracker.name);
  };

  // Confirm tracker rename
  const handleConfirmRenameTracker = (trackerId: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    if (editingTrackerName.trim()) {
      onRenameTracker(trackerId, editingTrackerName.trim());
    }
    setEditingTrackerId(null);
  };

  // Cancel tracker rename
  const handleCancelRenameTracker = (e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setEditingTrackerId(null);
  };

  // Add new folder
  const handleAddFolder = () => {
    if (!newFolderName.trim()) return;
    onCreateFolder(newFolderName.trim());
    setNewFolderName('');
    setShowNewFolderInput(false);
  };

  const toggleFolder = (folderId: string) => {
    setExpandedFolders((prev) => ({
      ...prev,
      [folderId]: !prev[folderId],
    }));
  };

  // Tracker deletion request handler
  const handleInitiateDeleteTracker = (tracker: Tracker, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!canManageTracker(tracker)) {
      setCannotDeleteNotice(
        `Permission Restricted: Only Administrator or assigned Project Handler can delete "${tracker.name}".`
      );
      return;
    }
    if (trackers.length <= 1) {
      setCannotDeleteNotice(
        `Cannot delete "${tracker.name}". At least one project tracker must remain in the directory.`
      );
      return;
    }
    setTrackerToDelete(tracker);
  };

  // Tracker deletion confirmed
  const handleConfirmDeleteTracker = () => {
    if (!trackerToDelete) return;
    const name = trackerToDelete.name;
    onDeleteTracker(trackerToDelete.id);
    setTrackerToDelete(null);
    setToastMessage(`Deleted tracker "${name}".`);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Folder deletion request handler
  const handleInitiateDeleteFolder = (folder: TrackerFolder, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!canCreate) {
      setCannotDeleteNotice(
        `Permission Restricted: Only Administrators can delete folders.`
      );
      return;
    }
    if (folders.length <= 1) {
      setCannotDeleteNotice(
        `Cannot delete "${folder.name}". At least one folder must remain in the directory.`
      );
      return;
    }
    setFolderToDelete(folder);
  };

  // Folder deletion confirmed
  const handleConfirmDeleteFolder = () => {
    if (!folderToDelete || !onDeleteFolder) return;
    const name = folderToDelete.name;
    onDeleteFolder(folderToDelete.id);
    setFolderToDelete(null);
    setToastMessage(`Deleted folder "${name}". Trackers were preserved.`);
    setTimeout(() => setToastMessage(null), 3500);
  };

  if (isCollapsed) {
    return (
      <aside className="w-14 bg-slate-950 border-r border-slate-800 flex flex-col items-center py-3.5 space-y-4 shrink-0 transition-all duration-200">
        <button
          type="button"
          onClick={onToggleCollapse}
          className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          title="Expand sidebar"
        >
          <ChevronRight className="w-4 h-4" />
        </button>

        <button
          type="button"
          onClick={onOpenGlobalSearch}
          className="p-2 text-slate-400 hover:text-sky-400 rounded-lg hover:bg-slate-800 transition-colors"
          title="Search trackers"
        >
          <Search className="w-4 h-4" />
        </button>

        {canCreate && (
          <button
            type="button"
            onClick={() => onCreateTracker()}
            className="p-2 text-indigo-400 hover:text-white rounded-lg hover:bg-indigo-600/40 transition-colors"
            title="Create new tracker"
          >
            <Plus className="w-4 h-4" />
          </button>
        )}

        <div className="w-6 h-px bg-slate-800" />

        {/* Tracker Quick Icons */}
        <div className="flex-1 overflow-y-auto space-y-2 w-full flex flex-col items-center">
          {trackers.map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => onSelectTracker(t.id)}
              className={`p-2 rounded-lg text-xs transition-colors ${
                t.id === activeTrackerId
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
              title={t.name}
            >
              <Table className="w-4 h-4" />
            </button>
          ))}
        </div>
      </aside>
    );
  }

  return (
    <>
      <aside className="w-72 bg-slate-950 border-r border-slate-800 flex flex-col shrink-0 text-slate-200 transition-all duration-200 select-none">
        {/* Sidebar Header */}
        <div className="p-3.5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Table className="w-4 h-4 text-indigo-400" />
            <span className="text-xs font-bold uppercase tracking-wider text-white">
              Trackers Directory
            </span>
          </div>
          <button
            type="button"
            onClick={onToggleCollapse}
            className="p-1 text-slate-400 hover:text-white rounded hover:bg-slate-800 transition-colors"
            title="Collapse sidebar"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
        </div>

        {/* Global Search Shortcut & Action Buttons */}
        <div className="p-3 border-b border-slate-800/80 space-y-2">
          <button
            type="button"
            onClick={onOpenGlobalSearch}
            className="w-full px-3 py-1.5 bg-slate-900 hover:bg-slate-800/90 border border-slate-800 rounded-lg text-xs text-slate-400 flex items-center justify-between transition-colors"
          >
            <span className="flex items-center gap-1.5">
              <Search className="w-3.5 h-3.5" />
              Search trackers...
            </span>
            <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-800 text-slate-400">
              Ctrl+F
            </span>
          </button>

          {canCreate && (
            <div className="grid grid-cols-2 gap-1.5">
              <button
                type="button"
                onClick={() => onCreateTracker()}
                className="py-1.5 px-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-md text-xs font-semibold flex items-center justify-center gap-1 transition-colors shadow-xs"
              >
                <Plus className="w-3.5 h-3.5" />
                New Tracker
              </button>
              <button
                type="button"
                onClick={() => setShowNewFolderInput(!showNewFolderInput)}
                className="py-1.5 px-2 bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 rounded-md text-xs font-medium flex items-center justify-center gap-1 transition-colors"
              >
                <FolderPlus className="w-3.5 h-3.5 text-sky-400" />
                New Folder
              </button>
            </div>
          )}

          {showNewFolderInput && (
            <div className="flex items-center gap-1 pt-1">
              <input
                type="text"
                autoFocus
                value={newFolderName}
                onChange={(e) => setNewFolderName(e.target.value)}
                placeholder="Folder Name..."
                className="flex-1 px-2 py-1 text-xs bg-slate-900 border border-slate-700 rounded text-white focus:outline-hidden focus:border-indigo-500"
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleAddFolder();
                  if (e.key === 'Escape') setShowNewFolderInput(false);
                }}
              />
              <button
                type="button"
                onClick={handleAddFolder}
                className="p-1 bg-indigo-600 hover:bg-indigo-500 text-white rounded transition-colors"
                title="Save Folder"
              >
                <Check className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={() => setShowNewFolderInput(false)}
                className="p-1 text-slate-400 hover:text-white rounded"
                title="Cancel"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
        </div>

        {/* Folders and Trackers Tree */}
        <div className="flex-1 overflow-y-auto p-2 space-y-3">
          {folders.map((folder) => {
            const folderTrackers = trackers.filter((t) => t.folderId === folder.id);
            const isExpanded = expandedFolders[folder.id] ?? true;
            const isRenamingFolder = editingFolderId === folder.id;

            return (
              <div key={folder.id} className="space-y-1">
                {/* Folder Row */}
                <div
                  className="group flex items-center justify-between px-2 py-1.5 text-xs text-slate-300 hover:text-white rounded-md hover:bg-slate-900/70 font-semibold transition-colors"
                >
                  {isRenamingFolder ? (
                    /* Inline Folder Rename Input */
                    <div className="flex items-center gap-1 w-full" onClick={(e) => e.stopPropagation()}>
                      <FolderOpen className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                      <input
                        type="text"
                        autoFocus
                        value={editingFolderName}
                        onChange={(e) => setEditingFolderName(e.target.value)}
                        className="flex-1 px-1.5 py-0.5 text-xs bg-slate-900 border border-indigo-500 rounded text-white focus:outline-hidden"
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') handleConfirmRenameFolder(folder.id);
                          if (e.key === 'Escape') handleCancelRenameFolder();
                        }}
                      />
                      <button
                        type="button"
                        onClick={(e) => handleConfirmRenameFolder(folder.id, e)}
                        className="p-1 text-emerald-400 hover:text-emerald-300 hover:bg-slate-800 rounded"
                        title="Save folder name"
                      >
                        <Check className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={(e) => handleCancelRenameFolder(e)}
                        className="p-1 text-slate-400 hover:text-white hover:bg-slate-800 rounded"
                        title="Cancel"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ) : (
                    <>
                      {/* Folder Title Click to Toggle */}
                      <div
                        onClick={() => toggleFolder(folder.id)}
                        onDoubleClick={() => canCreate && handleStartRenameFolder(folder)}
                        className="flex items-center gap-1.5 truncate flex-1 cursor-pointer select-none"
                        title="Click to toggle, double-click to rename"
                      >
                        {isExpanded ? (
                          <FolderOpen className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                        ) : (
                          <Folder className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                        )}
                        <span className="truncate">{folder.name}</span>
                        <span className="text-[10px] text-slate-500 font-mono">({folderTrackers.length})</span>
                      </div>

                      {/* Folder Action Buttons */}
                      <div className="flex items-center gap-0.5 shrink-0 ml-1">
                        {canCreate && (
                          <>
                            <button
                              type="button"
                              onClick={(e) => handleStartRenameFolder(folder, e)}
                              className="p-1 text-slate-500 hover:text-sky-300 hover:bg-slate-800 rounded transition-colors"
                              title="Rename folder"
                            >
                              <Edit2 className="w-3 h-3" />
                            </button>
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                onCreateTracker(folder.id);
                              }}
                              title="Add tracker to this folder"
                              className="p-1 text-slate-500 hover:text-white hover:bg-slate-800 rounded transition-colors"
                            >
                              <Plus className="w-3 h-3" />
                            </button>
                            {folders.length > 1 && onDeleteFolder && (
                              <button
                                type="button"
                                onClick={(e) => handleInitiateDeleteFolder(folder, e)}
                                className="p-1 text-slate-500 hover:text-rose-400 hover:bg-slate-800 rounded opacity-60 group-hover:opacity-100 transition-opacity"
                                title="Delete folder"
                              >
                                <Trash2 className="w-3 h-3" />
                              </button>
                            )}
                          </>
                        )}
                      </div>
                    </>
                  )}
                </div>

                {/* Trackers inside this Folder */}
                {isExpanded && (
                  <div className="pl-3 space-y-0.5 border-l border-slate-800/80 ml-2.5">
                    {folderTrackers.map((tracker) => {
                      const isActive = tracker.id === activeTrackerId;
                      const isRenaming = editingTrackerId === tracker.id;
                      const hasTrackerAccess = canManageTracker(tracker);

                      return (
                        <div
                          key={tracker.id}
                          className={`group flex items-center justify-between px-2 py-1.5 rounded-md text-xs transition-colors ${
                            isActive
                              ? 'bg-indigo-600 text-white font-semibold shadow-xs'
                              : 'text-slate-300 hover:bg-slate-900 hover:text-white'
                          }`}
                        >
                          {isRenaming ? (
                            /* Inline Tracker Rename Input */
                            <div className="flex items-center gap-1 w-full" onClick={(e) => e.stopPropagation()}>
                              <Table className="w-3.5 h-3.5 shrink-0 opacity-80" />
                              <input
                                type="text"
                                autoFocus
                                value={editingTrackerName}
                                onChange={(e) => setEditingTrackerName(e.target.value)}
                                className="flex-1 px-1.5 py-0.5 text-xs bg-slate-900 border border-indigo-400 rounded text-white focus:outline-hidden"
                                onKeyDown={(e) => {
                                  if (e.key === 'Enter') handleConfirmRenameTracker(tracker.id);
                                  if (e.key === 'Escape') handleCancelRenameTracker();
                                }}
                              />
                              <button
                                type="button"
                                onClick={(e) => handleConfirmRenameTracker(tracker.id, e)}
                                className="p-1 text-emerald-300 hover:bg-slate-800 rounded"
                                title="Save tracker name"
                              >
                                <Check className="w-3.5 h-3.5" />
                              </button>
                              <button
                                type="button"
                                onClick={(e) => handleCancelRenameTracker(e)}
                                className="p-1 text-slate-400 hover:text-white hover:bg-slate-800 rounded"
                                title="Cancel"
                              >
                                <X className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          ) : (
                            <>
                              {/* Tracker Select / Double-Click to Rename */}
                              <div
                                onClick={() => onSelectTracker(tracker.id)}
                                onDoubleClick={() => hasTrackerAccess && handleStartRenameTracker(tracker)}
                                className="flex items-center gap-1.5 truncate flex-1 cursor-pointer select-none"
                                title="Click to open tracker, double-click to rename"
                              >
                                <Table className="w-3.5 h-3.5 shrink-0 opacity-70" />
                                <span className="truncate">{tracker.name}</span>
                                <span className="text-[10px] text-slate-400 font-mono">
                                  ({tracker.rows.length})
                                </span>
                              </div>

                              {/* Quick Actions (Duplicate, Rename, Delete) */}
                              {hasTrackerAccess && (
                                <div
                                  className={`flex items-center gap-1 shrink-0 ml-1 transition-opacity ${
                                    isActive ? 'opacity-100' : 'opacity-70 group-hover:opacity-100'
                                  }`}
                                >
                                  <button
                                    type="button"
                                    onClick={(e) => handleStartRenameTracker(tracker, e)}
                                    className={`p-1 rounded hover:bg-black/30 transition-colors ${
                                      isActive ? 'text-white' : 'text-slate-400 hover:text-white'
                                    }`}
                                    title="Rename tracker"
                                  >
                                    <Edit2 className="w-3 h-3" />
                                  </button>
                                  <button
                                    type="button"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      onDuplicateTracker(tracker.id);
                                    }}
                                    className={`p-1 rounded hover:bg-black/30 transition-colors ${
                                      isActive ? 'text-white' : 'text-slate-400 hover:text-white'
                                    }`}
                                    title="Duplicate tracker"
                                  >
                                    <Copy className="w-3 h-3" />
                                  </button>
                                  {/* Delete Tracker Icon with In-App Confirmation */}
                                  <button
                                    type="button"
                                    onClick={(e) => handleInitiateDeleteTracker(tracker, e)}
                                    className={`p-1 rounded transition-colors ${
                                      isActive
                                        ? 'text-rose-200 hover:text-white hover:bg-rose-700/60'
                                        : 'text-rose-400 hover:text-rose-200 hover:bg-rose-900/50'
                                    }`}
                                    title={`Delete tracker "${tracker.name}"`}
                                    aria-label={`Delete tracker ${tracker.name}`}
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </button>
                                </div>
                              )}
                            </>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Sidebar Footer */}
        <div className="p-3 border-t border-slate-800 bg-slate-950 text-[11px] text-slate-400 flex items-center justify-between">
          <span>{trackers.length} Active Trackers</span>
          <span className="font-mono text-emerald-400">PHP (₱) Default</span>
        </div>
      </aside>

      {/* IN-APP MODAL: Delete Tracker Confirmation */}
      {trackerToDelete && (
        <div
          className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-150"
          onClick={() => setTrackerToDelete(null)}
        >
          <div
            className="w-full max-w-md bg-slate-900 border border-slate-700 rounded-xl shadow-2xl p-5 text-slate-200"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start gap-3.5 mb-4">
              <div className="w-10 h-10 rounded-full bg-rose-500/20 border border-rose-500/30 flex items-center justify-center shrink-0">
                <Trash2 className="w-5 h-5 text-rose-400" />
              </div>
              <div className="flex-1">
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  Delete Project Tracker
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  Are you sure you want to delete this tracker from the directory?
                </p>
              </div>
            </div>

            <div className="p-3 bg-slate-950/80 border border-slate-800 rounded-lg mb-4 space-y-1.5 text-xs">
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Tracker Name:</span>
                <span className="font-semibold text-white">{trackerToDelete.name}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Site Records / Rows:</span>
                <span className="font-mono text-amber-300 font-bold">{trackerToDelete.rows.length} rows</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Folder:</span>
                <span className="text-slate-300">
                  {folders.find((f) => f.id === trackerToDelete.folderId)?.name || 'General'}
                </span>
              </div>
            </div>

            <div className="p-2.5 bg-rose-950/30 border border-rose-800/40 rounded-lg mb-4 text-xs text-rose-300 flex items-start gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              <span>
                All site data, milestone schedules, SLA logs, and checklists in this tracker will be removed.
              </span>
            </div>

            <div className="flex items-center justify-end gap-2.5">
              <button
                type="button"
                onClick={() => setTrackerToDelete(null)}
                className="px-3.5 py-1.5 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmDeleteTracker}
                className="px-4 py-1.5 text-xs font-bold text-white bg-rose-600 hover:bg-rose-500 rounded-lg transition-colors flex items-center gap-1.5 shadow-md shadow-rose-950/50"
              >
                <Trash2 className="w-3.5 h-3.5" />
                Confirm Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {/* IN-APP MODAL: Delete Folder Confirmation */}
      {folderToDelete && (
        <div
          className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-150"
          onClick={() => setFolderToDelete(null)}
        >
          <div
            className="w-full max-w-md bg-slate-900 border border-slate-700 rounded-xl shadow-2xl p-5 text-slate-200"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start gap-3.5 mb-4">
              <div className="w-10 h-10 rounded-full bg-rose-500/20 border border-rose-500/30 flex items-center justify-center shrink-0">
                <Trash2 className="w-5 h-5 text-rose-400" />
              </div>
              <div className="flex-1">
                <h3 className="text-base font-bold text-white">
                  Delete Folder
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  Delete folder "{folderToDelete.name}"?
                </p>
              </div>
            </div>

            <p className="text-xs text-slate-300 mb-4 bg-slate-950 p-3 rounded-lg border border-slate-800">
              Trackers currently in this folder will not be lost; they will be moved to the primary folder.
            </p>

            <div className="flex items-center justify-end gap-2.5">
              <button
                type="button"
                onClick={() => setFolderToDelete(null)}
                className="px-3.5 py-1.5 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmDeleteFolder}
                className="px-4 py-1.5 text-xs font-bold text-white bg-rose-600 hover:bg-rose-500 rounded-lg transition-colors flex items-center gap-1.5"
              >
                <Trash2 className="w-3.5 h-3.5" />
                Delete Folder
              </button>
            </div>
          </div>
        </div>
      )}

      {/* IN-APP MODAL: Cannot Delete Notice (1 tracker left or permission restriction) */}
      {cannotDeleteNotice && (
        <div
          className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-150"
          onClick={() => setCannotDeleteNotice(null)}
        >
          <div
            className="w-full max-w-md bg-slate-900 border border-slate-700 rounded-xl shadow-2xl p-5 text-slate-200"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start gap-3.5 mb-4">
              <div className="w-10 h-10 rounded-full bg-amber-500/20 border border-amber-500/30 flex items-center justify-center shrink-0">
                <AlertTriangle className="w-5 h-5 text-amber-400" />
              </div>
              <div className="flex-1">
                <h3 className="text-base font-bold text-white">Action Not Allowed</h3>
                <p className="text-xs text-slate-300 mt-2 leading-relaxed">
                  {cannotDeleteNotice}
                </p>
              </div>
            </div>

            <div className="flex items-center justify-end pt-2">
              <button
                type="button"
                onClick={() => setCannotDeleteNotice(null)}
                className="px-4 py-1.5 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg transition-colors shadow-xs"
              >
                Understood
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Floating Notification Toast */}
      {toastMessage && (
        <div className="fixed bottom-5 left-5 z-50 bg-slate-900 text-white px-4 py-2.5 rounded-xl border border-slate-700 shadow-xl text-xs flex items-center gap-2 animate-in slide-in-from-bottom-2 duration-200">
          <Info className="w-4 h-4 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}
    </>
  );
};
