import React, { useState } from 'react';
import { Tracker, SlaScopeType, ProjectSlaConfig, SlaMilestoneTemplate, TrackerRow } from '../types/tracker';
import {
  SLA_SCOPE_PRESETS,
  getEffectiveTrackerSlaConfig,
  createMilestonesFromTemplate,
  addDaysToDateString,
  getLocalDateString,
  normalizeToStandardDate,
} from '../utils/excelUtils';
import {
  X,
  Target,
  Clock,
  Sparkles,
  Check,
  Plus,
  Trash2,
  ArrowUp,
  ArrowDown,
  RotateCcw,
  ShieldCheck,
  AlertCircle,
  FileCheck,
  Layers,
  ChevronRight,
} from 'lucide-react';

export interface ProjectSlaCustomizerModalProps {
  isOpen: boolean;
  onClose: () => void;
  tracker: Tracker;
  onSaveProjectSla: (updatedTracker: Tracker) => void;
  canEdit: boolean;
}

export const ProjectSlaCustomizerModal: React.FC<ProjectSlaCustomizerModalProps> = ({
  isOpen,
  onClose,
  tracker,
  onSaveProjectSla,
  canEdit,
}) => {
  if (!isOpen) return null;

  const currentCfg = getEffectiveTrackerSlaConfig(tracker);

  const [selectedScope, setSelectedScope] = useState<SlaScopeType>(currentCfg.scopeType);
  const [scopeName, setScopeName] = useState(currentCfg.scopeName);
  const [targetDays, setTargetDays] = useState<number>(currentCfg.targetDays);
  const [description, setDescription] = useState(currentCfg.description || '');
  const [milestones, setMilestones] = useState<SlaMilestoneTemplate[]>(() =>
    JSON.parse(JSON.stringify(currentCfg.milestones))
  );

  const [applyToExistingSites, setApplyToExistingSites] = useState(true);
  const [savedFeedback, setSavedFeedback] = useState<string | null>(null);

  // Switch preset
  const handleSelectPreset = (preset: ProjectSlaConfig) => {
    setSelectedScope(preset.scopeType);
    setScopeName(preset.scopeName);
    setTargetDays(preset.targetDays);
    setDescription(preset.description || '');
    setMilestones(JSON.parse(JSON.stringify(preset.milestones)));
  };

  const handleUpdateMilestone = (idx: number, updates: Partial<SlaMilestoneTemplate>) => {
    setMilestones((prev) => {
      const next = [...prev];
      next[idx] = { ...next[idx], ...updates };
      // If last milestone target days changed, update overall target days
      if (idx === next.length - 1 && updates.targetDaysFromTrigger !== undefined) {
        setTargetDays(updates.targetDaysFromTrigger);
      }
      return next;
    });
  };

  const handleAddMilestone = () => {
    const lastDay = milestones.length > 0 ? milestones[milestones.length - 1].targetDaysFromTrigger : 0;
    const newDay = lastDay + 7;
    const newTpl: SlaMilestoneTemplate = {
      name: `New Milestone Stage ${milestones.length + 1}`,
      targetDaysFromTrigger: newDay,
      description: 'Custom milestone requirement',
    };
    const updated = [...milestones, newTpl];
    setMilestones(updated);
    setTargetDays(newDay);
    if (selectedScope !== 'custom') setSelectedScope('custom');
  };

  const handleRemoveMilestone = (idx: number) => {
    if (milestones.length <= 1) return;
    const updated = milestones.filter((_, i) => i !== idx);
    setMilestones(updated);
    if (updated.length > 0) {
      setTargetDays(updated[updated.length - 1].targetDaysFromTrigger);
    }
    if (selectedScope !== 'custom') setSelectedScope('custom');
  };

  const handleMoveUp = (idx: number) => {
    if (idx <= 0) return;
    setMilestones((prev) => {
      const next = [...prev];
      const temp = next[idx];
      next[idx] = next[idx - 1];
      next[idx - 1] = temp;
      return next;
    });
  };

  const handleMoveDown = (idx: number) => {
    if (idx >= milestones.length - 1) return;
    setMilestones((prev) => {
      const next = [...prev];
      const temp = next[idx];
      next[idx] = next[idx + 1];
      next[idx + 1] = temp;
      return next;
    });
  };

  const handleSave = () => {
    if (!canEdit) return;

    // Sort milestones by target days
    const sortedMilestones = [...milestones].sort(
      (a, b) => a.targetDaysFromTrigger - b.targetDaysFromTrigger
    );
    const finalTargetDays =
      sortedMilestones.length > 0
        ? sortedMilestones[sortedMilestones.length - 1].targetDaysFromTrigger
        : targetDays;

    const newSlaConfig: ProjectSlaConfig = {
      scopeType: selectedScope,
      scopeName: scopeName.trim() || `${finalTargetDays}-Day Target SLA`,
      targetDays: finalTargetDays,
      description: description.trim(),
      milestones: sortedMilestones,
    };

    let updatedRows = [...(tracker.rows || [])];

    if (applyToExistingSites) {
      updatedRows = updatedRows.map((row) => {
        if (!row || row.siteId === 'SUMMARY' || row.values?.site_id === 'SUMMARY') return row;
        const trigger = normalizeToStandardDate(row.slaData?.triggerDate) || getLocalDateString();
        const calculatedTarget = addDaysToDateString(trigger, finalTargetDays);

        // Generate updated milestones preserving completed statuses
        const newSiteMilestones = createMilestonesFromTemplate(sortedMilestones, trigger, calculatedTarget);
        if (Array.isArray(row.slaData?.milestones)) {
          const oldStatusMap = new Map(row.slaData.milestones.map((m) => [m.name.toLowerCase().trim(), m.status]));
          newSiteMilestones.forEach((nm) => {
            const oldStatus = oldStatusMap.get(nm.name.toLowerCase().trim());
            if (oldStatus) nm.status = oldStatus;
          });
        }

        return {
          ...row,
          values: {
            ...row.values,
            target_on_air_date: calculatedTarget,
          },
          slaData: {
            ...row.slaData,
            targetDays: finalTargetDays,
            slaScopeName: newSlaConfig.scopeName,
            scopeType: selectedScope,
            milestones: newSiteMilestones,
          },
          updatedAt: new Date().toISOString(),
        };
      });
    }

    const updatedTracker: Tracker = {
      ...tracker,
      slaConfig: newSlaConfig,
      rows: updatedRows,
      updatedAt: new Date().toISOString(),
    };

    onSaveProjectSla(updatedTracker);
    setSavedFeedback(
      `✓ Successfully saved SLA target (${finalTargetDays} Days · ${newSlaConfig.scopeName})${
        applyToExistingSites ? ` and updated all ${updatedRows.length} sites in project!` : ' as project default!'
      }`
    );
    setTimeout(() => {
      setSavedFeedback(null);
      onClose();
    }, 1200);
  };

  const sampleTrigger = getLocalDateString();
  const sampleTarget = addDaysToDateString(sampleTrigger, targetDays);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-xs animate-in fade-in">
      <div className="relative w-full max-w-4xl max-h-[92vh] flex flex-col rounded-2xl bg-slate-900 border border-slate-700 shadow-2xl text-slate-100 overflow-hidden">
        {/* Header */}
        <div className="px-5 py-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30">
              <Target className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-white">Customized Project SLA Target</h2>
                <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[11px] font-mono font-bold">
                  {targetDays} Days Target
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Target per project: Configure exact SLA days and milestone stages for <strong>{tracker.name}</strong>.
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-5">
          {/* Highlighted Notice for 21-Day Post-Con Endorsements */}
          <div className="p-3.5 rounded-xl bg-gradient-to-r from-amber-950/40 via-indigo-950/30 to-slate-900 border border-amber-600/40 flex items-start gap-3">
            <Sparkles className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
            <div className="text-xs">
              <div className="font-bold text-amber-200">
                Post-Con Securing Endorsement Optimization (21 Days)
              </div>
              <p className="text-slate-300 mt-0.5 leading-relaxed">
                When a project endorsement is strictly for <strong>securing post-construction clearance and joint audit</strong>, it only takes <strong>21 days</strong> to secure rather than a 156-day full turnkey rollout. Selecting the 21-Day Post-Con preset recalculates SLA warnings, milestones, and target deadlines tailored specifically to that 21-day timeline.
              </p>
            </div>
          </div>

          {/* Preset Selector Cards */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5 text-sky-400" />
              <span>Select SLA Project Scope & Preset</span>
            </label>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
              {SLA_SCOPE_PRESETS.map((preset) => {
                const isSelected = selectedScope === preset.scopeType;
                const isPostCon = preset.scopeType === 'post_con_21d';

                return (
                  <div
                    key={preset.scopeType}
                    onClick={() => handleSelectPreset(preset)}
                    className={`p-3 rounded-xl border cursor-pointer transition-all flex flex-col justify-between ${
                      isSelected
                        ? 'bg-indigo-950/60 border-indigo-500 ring-2 ring-indigo-500/50 shadow-md'
                        : isPostCon
                        ? 'bg-amber-950/20 border-amber-700/60 hover:border-amber-500'
                        : 'bg-slate-950 border-slate-800 hover:border-slate-700 hover:bg-slate-850'
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between gap-1.5">
                        <span className="font-bold text-xs text-white flex items-center gap-1">
                          {isPostCon && '⭐ '}
                          {preset.scopeName}
                        </span>
                        <span
                          className={`px-1.5 py-0.5 rounded text-[10px] font-mono font-bold ${
                            isPostCon
                              ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                              : 'bg-slate-800 text-slate-300'
                          }`}
                        >
                          {preset.targetDays}d
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400 mt-1 line-clamp-2 leading-tight">
                        {preset.description}
                      </p>
                    </div>

                    <div className="mt-2.5 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[10px] text-slate-400">
                      <span>{preset.milestones.length} Milestone Stages</span>
                      {isSelected ? (
                        <span className="text-emerald-400 font-bold flex items-center gap-0.5">
                          <Check className="w-3 h-3" /> Active
                        </span>
                      ) : (
                        <span className="text-slate-500">Click to apply</span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Scope Name & Total Target Days Configuration */}
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
            <div className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center justify-between">
              <span>SLA Target Settings</span>
              <span className="text-[11px] font-normal text-sky-400 font-mono">
                Sample: {sampleTrigger} → {sampleTarget} ({targetDays} days)
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="sm:col-span-2 space-y-1">
                <label className="text-[11px] font-medium text-slate-400">SLA Scope Title / Endorsement Name:</label>
                <input
                  type="text"
                  value={scopeName}
                  onChange={(e) => {
                    setScopeName(e.target.value);
                    if (selectedScope !== 'custom') setSelectedScope('custom');
                  }}
                  placeholder="e.g. Securing Post-Con Only (21d SLA)"
                  className="w-full px-3 py-1.5 text-xs bg-slate-900 border border-slate-800 rounded-lg text-white focus:outline-hidden focus:border-indigo-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[11px] font-medium text-slate-400">Total SLA Target (Days):</label>
                <div className="flex items-center gap-1.5">
                  <input
                    type="number"
                    min={1}
                    max={365}
                    value={targetDays}
                    onChange={(e) => {
                      const v = Math.max(1, parseInt(e.target.value, 10) || 1);
                      setTargetDays(v);
                      if (selectedScope !== 'custom') setSelectedScope('custom');
                      // Update the last milestone's target days if present
                      if (milestones.length > 0) {
                        setMilestones((prev) => {
                          const next = [...prev];
                          next[next.length - 1].targetDaysFromTrigger = v;
                          return next;
                        });
                      }
                    }}
                    className="w-full px-3 py-1.5 text-xs bg-slate-900 border border-slate-800 rounded-lg text-amber-400 font-bold font-mono focus:outline-hidden focus:border-indigo-500"
                  />
                  <span className="text-xs text-slate-400 font-bold">Days</span>
                </div>
              </div>
            </div>
          </div>

          {/* Milestone Stages Editor */}
          <div className="space-y-2.5">
            <div className="flex items-center justify-between">
              <div className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                <FileCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>Milestone Stages & Day Offsets ({milestones.length} Stages)</span>
              </div>

              <button
                type="button"
                onClick={handleAddMilestone}
                className="px-2.5 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold flex items-center gap-1 transition-colors"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Stage</span>
              </button>
            </div>

            <div className="border border-slate-800 rounded-xl overflow-hidden bg-slate-950">
              <table className="w-full text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-900/90 border-b border-slate-800 text-slate-400 font-semibold text-[11px]">
                    <th className="px-3 py-2 text-left w-12">#</th>
                    <th className="px-3 py-2 text-left">Stage Name & Requirement</th>
                    <th className="px-3 py-2 text-center w-36">Cumulative Day Target</th>
                    <th className="px-3 py-2 text-center w-28">Sample Date</th>
                    <th className="px-3 py-2 text-right w-24">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-850">
                  {milestones.map((ms, idx) => {
                    const prevCumulative = idx > 0 ? milestones[idx - 1].targetDaysFromTrigger : 0;
                    const stageDays = Math.max(1, ms.targetDaysFromTrigger - prevCumulative);
                    const calcDate = addDaysToDateString(sampleTrigger, ms.targetDaysFromTrigger);

                    return (
                      <tr key={idx} className="hover:bg-slate-900/50 transition-colors">
                        <td className="px-3 py-2 text-slate-500 font-mono font-bold text-[11px]">
                          {idx + 1}
                        </td>
                        <td className="px-3 py-2">
                          <input
                            type="text"
                            value={ms.name}
                            onChange={(e) => handleUpdateMilestone(idx, { name: e.target.value })}
                            className="w-full px-2 py-1 text-xs bg-slate-900 border border-slate-800 rounded text-slate-100 font-medium focus:outline-hidden focus:border-indigo-500"
                            placeholder="Milestone stage title..."
                          />
                        </td>
                        <td className="px-3 py-2 text-center">
                          <div className="flex items-center justify-center gap-1">
                            <span className="text-[10px] text-slate-500">Day</span>
                            <input
                              type="number"
                              min={1}
                              max={365}
                              value={ms.targetDaysFromTrigger}
                              onChange={(e) =>
                                handleUpdateMilestone(idx, {
                                  targetDaysFromTrigger: Math.max(1, parseInt(e.target.value, 10) || 1),
                                })
                              }
                              className="w-16 px-2 py-1 text-center text-xs font-mono font-bold bg-slate-900 border border-slate-800 rounded text-amber-400 focus:outline-hidden focus:border-indigo-500"
                            />
                            <span className="text-[10px] text-slate-500 font-mono">
                              (+{stageDays}d)
                            </span>
                          </div>
                        </td>
                        <td className="px-3 py-2 text-center font-mono text-[11px] text-sky-400">
                          {calcDate}
                        </td>
                        <td className="px-3 py-2 text-right">
                          <div className="flex items-center justify-end gap-1">
                            <button
                              type="button"
                              onClick={() => handleMoveUp(idx)}
                              disabled={idx === 0}
                              className="p-1 text-slate-400 hover:text-white disabled:opacity-20 rounded hover:bg-slate-800"
                              title="Move up"
                            >
                              <ArrowUp className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => handleMoveDown(idx)}
                              disabled={idx === milestones.length - 1}
                              className="p-1 text-slate-400 hover:text-white disabled:opacity-20 rounded hover:bg-slate-800"
                              title="Move down"
                            >
                              <ArrowDown className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => handleRemoveMilestone(idx)}
                              disabled={milestones.length <= 1}
                              className="p-1 text-rose-400 hover:text-rose-300 disabled:opacity-20 rounded hover:bg-slate-800"
                              title="Delete stage"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Batch Application Option */}
          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
            <label className="flex items-center gap-2.5 cursor-pointer">
              <input
                type="checkbox"
                checked={applyToExistingSites}
                onChange={(e) => setApplyToExistingSites(e.target.checked)}
                className="w-4 h-4 rounded text-indigo-500 focus:ring-indigo-500 bg-slate-900 border-slate-700"
              />
              <div className="text-xs">
                <span className="font-bold text-white block">
                  Apply customized SLA to all {tracker.rows?.length || 0} existing sites in this project
                </span>
                <span className="text-[11px] text-slate-400 block mt-0.5">
                  Recalculates target completion dates and applies this {targetDays}-day SLA milestone roadmap across all current rows.
                </span>
              </div>
            </label>
          </div>
        </div>

        {/* Footer */}
        <div className="px-5 py-3.5 bg-slate-950 border-t border-slate-800 flex items-center justify-between shrink-0">
          <div className="text-xs text-slate-400">
            {savedFeedback ? (
              <span className="text-emerald-400 font-bold flex items-center gap-1.5 animate-in fade-in">
                <Check className="w-4 h-4" />
                {savedFeedback}
              </span>
            ) : (
              <span>Target per project: <strong>{targetDays} Days Total SLA</strong></span>
            )}
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg text-xs font-semibold text-slate-300 bg-slate-800 hover:bg-slate-700 transition-colors"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleSave}
              disabled={!canEdit}
              className="px-5 py-2 rounded-lg text-xs font-bold text-white bg-amber-600 hover:bg-amber-500 disabled:opacity-50 transition-colors flex items-center gap-1.5 shadow-md shadow-amber-950"
            >
              <Check className="w-4 h-4" />
              <span>Save & Apply Project SLA</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
